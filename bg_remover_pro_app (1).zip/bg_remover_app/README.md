# BG Remover Pro — Setup Guide (Roman Urdu)

App ka naam: **BG Remover Pro**
Framework: **Flutter** (ek code se Android + iOS dono ban jaate hain)

---

## 📦 12 TOP FEATURES (jo is app mein hain)

1. **AI Photo Background Remover** — one-tap, on-device AI (free, no API key)
2. **AI Video Background Remover** — frame-by-frame processing
3. **Background Replace** — solid color / blur / custom image
4. **Batch Processing** — multiple photos ek saath
5. **AI Auto Enhance** — brightness/contrast/saturation behtar
6. **My Watermark / Logo Studio** — sirf USER ka apna logo/text (app koi watermark force nahi karti)
7. **Green Screen Studio** — video editors ke liye chroma-key export
8. **Sticker / Transparent PNG Export**
9. **Before/After Comparison Slider**
10. **Local History/Gallery** — bina cloud ke
11. **Multi-language Settings**
12. **Premium Plan** (ads-free) + Rewarded ad option

---

## 🎯 AD FLOW (jaisa aapne manga)

Har "Remove Background" button dabane par:
1. **Interstitial AD pehle dikhti hai**
2. Ad band hone ke baad hi AI processing shuru hoti hai
3. Result (clean, **bina kisi app watermark ke**) dikhta hai

Ye logic `lib/services/ad_service.dart` mein `showInterstitialBeforeProcessing()` function mein hai.

---

## 🔑 STEP 1: AdMob Setup (ZAROORI — launch se pehle)

Aapne diya hai: `pub-7479194464069036` — ye aapki **AdMob Publisher ID** hai.

App ko chalane ke liye poori **App ID** chahiye, jo is tarah dikhti hai:
```
ca-app-pub-7479194464069036~XXXXXXXXXX
```

### Kaise lein:
1. https://apps.admob.com pe login karein
2. **Apps → Add App** → "BG Remover Pro" naam se Android app add karein
3. Wahan se poori **App ID** copy karein
4. `android/app/src/main/AndroidManifest.xml` mein is line mein paste karein:
   ```xml
   <meta-data
       android:name="com.google.android.gms.ads.APPLICATION_ID"
       android:value="ca-app-pub-7479194464069036~XXXXXXXXXX"/>
   ```
5. Phir 3 **Ad Units** banayein (Interstitial, Banner, Rewarded) AdMob console mein
6. Unki IDs `lib/config/app_config.dart` mein daal dein (abhi test IDs hain):
   ```dart
   static const String interstitialAdUnitId = "YOUR_REAL_INTERSTITIAL_ID";
   static const String bannerAdUnitId = "YOUR_REAL_BANNER_ID";
   static const String rewardedAdUnitId = "YOUR_REAL_REWARDED_ID";
   ```

⚠️ **Important:** Jab tak real Ad Unit IDs nahi daalte, app TEST ads dikhayegi (Google ki taraf se diye hue safe test IDs) — ye normal hai, isse account ban nahi hota. Real IDs daalne ke baad hi real paisa banna shuru hoga.

---

## 🛠️ STEP 2: App Build Karna

Computer pe Flutter SDK install honi chahiye (flutter.dev se).

```bash
cd bg_remover_app
flutter pub get
flutter build apk --release
```

Build hone ke baad APK yahan milegi:
```
build/app/outputs/flutter-apk/app-release.apk
```

Ye wahi file hai jo Amazon Appstore aur Samsung Galaxy Store pe upload karni hai.

---

## 📤 STEP 3: Amazon Appstore pe Publish

1. https://developer.amazon.com pe free account banayein
2. **Apps & Services → Add New App**
3. APK file upload karein, screenshots/icon/description add karein
4. Submit for review (1-3 din lagte hain)

## 📤 STEP 4: Samsung Galaxy Store pe Publish

1. https://seller.samsungapps.com pe free account banayein
2. **Add New Application**
3. Same APK upload karein (alag `applicationId` rakhna behtar hai dono store ke liye conflict na ho)
4. Submit for review

---

## 💰 Paisa Kaise Aayega

- Jab users app use karenge → interstitial/banner ads dikhengi
- AdMob har impression/click pe paisa deta hai
- Jab balance **$100** cross ho jaye, AdMob automatically bank account mein transfer kar deta hai (Payment settings mein bank details add karni hongi)

---

## 📝 Important Notes

- App **koi watermark khud add nahi karti** — output hamesha clean hai
- Watermark sirf "My Watermark / Logo Studio" feature se, **sirf user ki marzi se** add hota hai
- Background removal **on-device AI** (Google ML Kit) use karti hai — koi paid API key abhi zaroori nahi
- Agar future mein non-human objects (jaise leather bags, gloves) ke liye zyada accurate results chahiye, to `bg_removal_service.dart` mein remove.bg jaisi cloud API add ki ja sakti hai (code mein comment section diya gaya hai)
