/// ============================================================
/// APP CONFIGURATION
/// Saari app-wide settings yahan hain — IDs, constants, etc.
/// ============================================================
class AppConfig {
  // ---------------- ADMOB ----------------
  // Aapka AdMob Publisher / App ID:
  static const String adMobAppId = "pub-7479194464069036";

  // NOTE: AdMob App ID format hota hai: ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY
  // (note the ~ tilde) — ye ALAG hoti hai Ad Unit IDs (jo / slash use
  // karti hain) se. Aapne abhi sirf Ad Unit IDs di hain, App ID nahi.
  // App ID abhi bhi AndroidManifest.xml mein TEST hai — neeche "ZAROORI"
  // section dekhein.

  // ✅ REAL Ad Unit IDs (aapne diye hain):
  static const String rewardedAdUnitId =
      "ca-app-pub-7479194464069036/8686941707"; // REAL - Rewarded
  static const String nativeAdvancedUnitId =
      "ca-app-pub-7479194464069036/8164197527"; // REAL - Native Advanced
  static const String bannerAdUnitId =
      "ca-app-pub-7479194464069036/7373860038"; // REAL - Banner

  // ⚠️ Interstitial ID nahi mila — abhi TEST ID hai. Background remove
  // se PEHLE wali ad isi unit se chalti hai, isliye ye sabse zaroori
  // hai. AdMob console mein "Interstitial" type ka naya ad unit banayein
  // aur neeche paste karein:
  static const String interstitialAdUnitId =
      "ca-app-pub-7479194464069036/1652583896"; // ✅ REAL - Interstitial

  // ---------------- APP BEHAVIOR ----------------
  static const String appName = "BG Remover Pro";

  // Interstitial ad HAMESHA background remove se PEHLE dikhegi (jaisa
  // aapne maanga). Har process se pehle naya ad load + show hoga.
  static const bool showAdBeforeEachProcess = true;

  // Free users ko kitne processes per din milte hain bina paid plan ke
  static const int freeProcessesPerDay = 15;

  // Premium subscription price (sirf reference ke liye, app store/Play
  // Billing / IAP se actual purchase setup hota hai)
  static const String premiumMonthlyPrice = "\$2.99";
}
