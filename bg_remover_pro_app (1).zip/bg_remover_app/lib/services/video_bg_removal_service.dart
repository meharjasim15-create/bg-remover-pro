import 'dart:io';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:path_provider/path_provider.dart';
import 'bg_removal_service.dart';

/// ============================================================
/// VIDEO BACKGROUND REMOVAL SERVICE
/// Process: video ke frames nikalo -> har frame se AI background
/// remove karo -> wapas video mein jodo (with transparent/replaced bg).
/// Heavy processing hai isliye progress callback diya gaya hai.
/// ============================================================
class VideoBgRemovalService {
  final BgRemovalService _photoService = BgRemovalService();

  /// Video ka background remove kar ke naye background (color/image) ke
  /// saath replace karta hai. Progress 0.0 to 1.0 callback se milta hai.
  Future<File> removeVideoBackground(
    File inputVideo, {
    required void Function(double progress) onProgress,
    String newBackgroundColorHex = "#00FF00", // default green screen
  }) async {
    final tempDir = await getTemporaryDirectory();
    final framesDir = Directory('${tempDir.path}/frames_${DateTime.now().millisecondsSinceEpoch}');
    await framesDir.create(recursive: true);

    // Step 1: Frames extract karo (10 fps - heavy processing ke liye optimized)
    onProgress(0.05);
    final extractCmd =
        '-i "${inputVideo.path}" -vf fps=10 "${framesDir.path}/frame_%04d.png"';
    await FFmpegKit.execute(extractCmd);
    onProgress(0.25);

    // Step 2: Har frame se background remove karo (AI processing)
    final frameFiles = framesDir
        .listSync()
        .where((f) => f.path.endsWith('.png'))
        .map((f) => File(f.path))
        .toList()
      ..sort((a, b) => a.path.compareTo(b.path));

    final processedDir = Directory('${tempDir.path}/processed_${DateTime.now().millisecondsSinceEpoch}');
    await processedDir.create(recursive: true);

    for (int i = 0; i < frameFiles.length; i++) {
      final processed = await _photoService.removeBackgroundFromImage(frameFiles[i]);
      final destPath = '${processedDir.path}/frame_${i.toString().padLeft(4, '0')}.png';
      await processed.copy(destPath);
      onProgress(0.25 + (0.6 * (i + 1) / frameFiles.length));
    }

    // Step 3: Processed frames ko wapas video mein assemble karo
    final outputPath = '${tempDir.path}/bg_removed_video_${DateTime.now().millisecondsSinceEpoch}.mp4';
    final assembleCmd =
        '-framerate 10 -i "${processedDir.path}/frame_%04d.png" -c:v libx264 -pix_fmt yuv420p "$outputPath"';
    final session = await FFmpegKit.execute(assembleCmd);
    final returnCode = await session.getReturnCode();

    onProgress(1.0);

    if (ReturnCode.isSuccess(returnCode)) {
      return File(outputPath);
    } else {
      throw Exception("Video processing failed");
    }
  }

  void dispose() {
    _photoService.dispose();
  }
}
