import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:google_mlkit_selfie_segmentation/google_mlkit_selfie_segmentation.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

/// ============================================================
/// BACKGROUND REMOVAL SERVICE (PHOTOS)
/// On-device AI (Google ML Kit Selfie Segmentation) — FREE,
/// koi paid API key ki zaroorat nahi, sab kuch phone pe hi
/// process hota hai (fast + private + no internet needed).
///
/// Agar future mein zyada accurate / non-human objects (jaise
/// products, JN9 gloves, leather bags) ke liye chahiye to
/// remove.bg jaisi cloud API bhi yahan add ki ja sakti hai —
/// us section ko neeche comment mein chhoda gaya hai.
/// ============================================================
class BgRemovalService {
  final SelfieSegmenter _segmenter = SelfieSegmenter(
    mode: SegmenterMode.single,
    enableRawSizeMask: true,
  );

  /// Photo se background remove karta hai, transparent PNG return karta hai.
  Future<File> removeBackgroundFromImage(File inputFile) async {
    final inputImage = InputImage.fromFile(inputFile);
    final mask = await _segmenter.processImage(inputImage);

    final originalBytes = await inputFile.readAsBytes();
    final original = img.decodeImage(originalBytes)!;

    final result = img.Image(width: original.width, height: original.height, numChannels: 4);

    final confidences = mask.confidences;
    final maskWidth = mask.width;
    final maskHeight = mask.height;

    for (int y = 0; y < original.height; y++) {
      for (int x = 0; x < original.width; x++) {
        final maskX = (x * maskWidth / original.width).floor();
        final maskY = (y * maskHeight / original.height).floor();
        final confidence = confidences[maskY * maskWidth + maskX];

        final pixel = original.getPixel(x, y);
        final alpha = (confidence * 255).round().clamp(0, 255);

        result.setPixelRgba(
          x, y, pixel.r.toInt(), pixel.g.toInt(), pixel.b.toInt(), alpha,
        );
      }
    }

    final outputDir = await getTemporaryDirectory();
    final outputPath =
        '${outputDir.path}/bg_removed_${DateTime.now().millisecondsSinceEpoch}.png';
    final outputFile = File(outputPath);
    await outputFile.writeAsBytes(img.encodePng(result));
    return outputFile;
  }

  /// Background ko solid color se replace karta hai
  Future<File> replaceBackgroundWithColor(File transparentPngFile, Color color) async {
    final bytes = await transparentPngFile.readAsBytes();
    final foreground = img.decodePng(bytes)!;

    final canvas = img.Image(width: foreground.width, height: foreground.height);
    img.fill(canvas, color: img.ColorRgb8(
      (color.r * 255).round(), (color.g * 255).round(), (color.b * 255).round(),
    ));
    img.compositeImage(canvas, foreground);

    final outputDir = await getTemporaryDirectory();
    final outputPath =
        '${outputDir.path}/bg_color_${DateTime.now().millisecondsSinceEpoch}.png';
    final outputFile = File(outputPath);
    await outputFile.writeAsBytes(img.encodePng(canvas));
    return outputFile;
  }

  /// Background ko custom image se replace karta hai
  Future<File> replaceBackgroundWithImage(File transparentPngFile, File backgroundFile) async {
    final fgBytes = await transparentPngFile.readAsBytes();
    final bgBytes = await backgroundFile.readAsBytes();
    final foreground = img.decodePng(fgBytes)!;
    var background = img.decodeImage(bgBytes)!;

    background = img.copyResize(background, width: foreground.width, height: foreground.height);
    img.compositeImage(background, foreground);

    final outputDir = await getTemporaryDirectory();
    final outputPath =
        '${outputDir.path}/bg_custom_${DateTime.now().millisecondsSinceEpoch}.png';
    final outputFile = File(outputPath);
    await outputFile.writeAsBytes(img.encodePng(background));
    return outputFile;
  }

  /// Background ko blur kar deta hai (asal background rakhte hue blur effect)
  Future<File> blurBackground(File originalFile, File transparentMaskFile) async {
    final origBytes = await originalFile.readAsBytes();
    final maskBytes = await transparentMaskFile.readAsBytes();
    var original = img.decodeImage(origBytes)!;
    final foreground = img.decodePng(maskBytes)!;

    final blurredBg = img.gaussianBlur(img.Image.from(original), radius: 15);
    img.compositeImage(blurredBg, foreground);

    final outputDir = await getTemporaryDirectory();
    final outputPath =
        '${outputDir.path}/bg_blur_${DateTime.now().millisecondsSinceEpoch}.png';
    final outputFile = File(outputPath);
    await outputFile.writeAsBytes(img.encodePng(blurredBg));
    return outputFile;
  }

  void dispose() {
    _segmenter.close();
  }
}

/* 
=========================================================================
OPTIONAL CLOUD API VERSION (zyada accurate, products/objects ke liye):
Agar aap sirf insano ke bajaye products (jaise JN9 gloves, leather bags)
ka background bhi remove karna chahte hain to remove.bg API behtar
result deti hai. Niche commented example:

Future<File> removeBackgroundCloudAPI(File inputFile) async {
  final apiKey = "YOUR_REMOVE_BG_API_KEY"; // remove.bg se lena hoga
  final uri = Uri.parse("https://api.remove.bg/v1.0/removebg");
  final request = http.MultipartRequest('POST', uri)
    ..headers['X-Api-Key'] = apiKey
    ..files.add(await http.MultipartFile.fromPath('image_file', inputFile.path))
    ..fields['size'] = 'auto';
  final response = await request.send();
  final bytes = await response.stream.toBytes();
  final outputDir = await getTemporaryDirectory();
  final outputFile = File('${outputDir.path}/cloud_removed.png');
  await outputFile.writeAsBytes(bytes);
  return outputFile;
}
=========================================================================
*/
