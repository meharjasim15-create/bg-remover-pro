import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

/// ============================================================
/// WATERMARK SERVICE
/// IMPORTANT: Ye app KOI bhi apna watermark ya logo automatically
/// nahi lagati — output hamesha CLEAN hota hai.
/// Watermark sirf tab lagta hai jab USER khud apna logo/text
/// is feature se manually add kare (apni JN9 / Tan & Stitch
/// branding ke liye, ya kisi bhi cheez ke liye).
/// ============================================================
class WatermarkService {
  /// User ka apna logo image background-removed photo pe add karta hai
  Future<File> addUserLogoWatermark({
    required File processedImage,
    required File userLogoFile,
    double opacity = 0.8,
    String position = "bottom-right", // bottom-right, bottom-left, top-right, top-left, center
    double sizePercent = 0.15, // logo, image ke width ka kitna % hoga
  }) async {
    final baseBytes = await processedImage.readAsBytes();
    final logoBytes = await userLogoFile.readAsBytes();

    final base = img.decodeImage(baseBytes)!;
    var logo = img.decodeImage(logoBytes)!;

    final targetLogoWidth = (base.width * sizePercent).round();
    final targetLogoHeight = (logo.height * targetLogoWidth / logo.width).round();
    logo = img.copyResize(logo, width: targetLogoWidth, height: targetLogoHeight);

    int x, y;
    const padding = 20;
    switch (position) {
      case "bottom-left":
        x = padding;
        y = base.height - logo.height - padding;
        break;
      case "top-right":
        x = base.width - logo.width - padding;
        y = padding;
        break;
      case "top-left":
        x = padding;
        y = padding;
        break;
      case "center":
        x = (base.width - logo.width) ~/ 2;
        y = (base.height - logo.height) ~/ 2;
        break;
      case "bottom-right":
      default:
        x = base.width - logo.width - padding;
        y = base.height - logo.height - padding;
    }

    img.compositeImage(base, logo, dstX: x, dstY: y, blend: img.BlendMode.alpha,
        opacity: (opacity * 255).round());

    final outputDir = await getTemporaryDirectory();
    final outputPath =
        '${outputDir.path}/watermarked_${DateTime.now().millisecondsSinceEpoch}.png';
    final outputFile = File(outputPath);
    await outputFile.writeAsBytes(img.encodePng(base));
    return outputFile;
  }

  /// User apna text watermark bhi add kar sakta hai (e.g. "Tan & Stitch")
  Future<File> addUserTextWatermark({
    required File processedImage,
    required String text,
    String position = "bottom-right",
  }) async {
    final baseBytes = await processedImage.readAsBytes();
    final base = img.decodeImage(baseBytes)!;

    final font = img.arial24;
    int x, y;
    const padding = 20;
    final textWidth = text.length * 12; // approx width

    switch (position) {
      case "bottom-left":
        x = padding;
        y = base.height - 40;
        break;
      case "top-right":
        x = base.width - textWidth - padding;
        y = padding;
        break;
      default:
        x = base.width - textWidth - padding;
        y = base.height - 40;
    }

    img.drawString(base, text, font: font, x: x, y: y,
        color: img.ColorRgba8(255, 255, 255, 200));

    final outputDir = await getTemporaryDirectory();
    final outputPath =
        '${outputDir.path}/watermarked_text_${DateTime.now().millisecondsSinceEpoch}.png';
    final outputFile = File(outputPath);
    await outputFile.writeAsBytes(img.encodePng(base));
    return outputFile;
  }
}
