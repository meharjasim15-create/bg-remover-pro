import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../config/app_config.dart';

/// ============================================================
/// AD SERVICE
/// Pura AdMob logic yahan handle hota hai:
///  - Interstitial ad processing se PEHLE (jaisa requested)
///  - Banner ad home screen pe
///  - Rewarded ad premium features temporarily unlock karne ke liye
/// ============================================================
class AdService {
  AdService._internal();
  static final AdService instance = AdService._internal();

  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  bool _isInterstitialReady = false;

  /// App start hote hi call karo (main.dart mein)
  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    _loadInterstitialAd();
    _loadRewardedAd();
  }

  // ---------------- INTERSTITIAL (background remove se pehle) ----------------
  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: AppConfig.interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialReady = true;
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              ad.dispose();
              _isInterstitialReady = false;
              _loadInterstitialAd(); // agla ad pehle se preload kar lo
            },
            onAdFailedToShowFullScreenContent: (ad, error) {
              ad.dispose();
              _isInterstitialReady = false;
              _loadInterstitialAd();
            },
          );
        },
        onAdFailedToLoad: (error) {
          _isInterstitialReady = false;
        },
      ),
    );
  }

  /// Background remove shuru karne se PEHLE ye call hota hai.
  /// Ad dikhne ke baad hi onAdComplete callback se asal processing chalti hai.
  Future<void> showInterstitialBeforeProcessing({
    required Future<void> Function() onAdComplete,
  }) async {
    if (_isInterstitialReady && _interstitialAd != null) {
      _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) async {
          ad.dispose();
          _isInterstitialReady = false;
          _loadInterstitialAd();
          await onAdComplete(); // ad band hote hi processing shuru
        },
        onAdFailedToShowFullScreenContent: (ad, error) async {
          ad.dispose();
          _isInterstitialReady = false;
          _loadInterstitialAd();
          await onAdComplete(); // ad fail ho to bhi processing rukni nahi chahiye
        },
      );
      await _interstitialAd!.show();
    } else {
      // Ad ready nahi to processing block na ho, seedha aage badho
      await onAdComplete();
    }
  }

  // ---------------- REWARDED (premium feature temp unlock) ----------------
  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: AppConfig.rewardedAdUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _rewardedAd = ad,
        onAdFailedToLoad: (error) => _rewardedAd = null,
      ),
    );
  }

  Future<void> showRewardedAd({
    required void Function() onUserEarnedReward,
  }) async {
    if (_rewardedAd == null) {
      _loadRewardedAd();
      return;
    }
    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _loadRewardedAd();
      },
    );
    await _rewardedAd!.show(
      onUserEarnedReward: (ad, reward) => onUserEarnedReward(),
    );
  }

  // ---------------- NATIVE ADVANCED ----------------
  /// Native ad load karta hai jo app ke design ke saath blend ho jaati hai
  /// (jaise home screen ke feature grid ke beech mein)
  NativeAd createNativeAd({required void Function(Ad) onLoaded}) {
    return NativeAd(
      adUnitId: AppConfig.nativeAdvancedUnitId,
      request: const AdRequest(),
      listener: NativeAdListener(
        onAdLoaded: onLoaded,
        onAdFailedToLoad: (ad, error) => ad.dispose(),
      ),
      nativeTemplateStyle: NativeTemplateStyle(
        templateType: TemplateType.medium,
        mainBackgroundColor: Colors.white,
        cornerRadius: 14,
      ),
    )..load();
  }

  // ---------------- BANNER ----------------
  BannerAd createBannerAd() {
    return BannerAd(
      adUnitId: AppConfig.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: const BannerAdListener(),
    )..load();
  }

  void dispose() {
    _interstitialAd?.dispose();
    _rewardedAd?.dispose();
  }
}
