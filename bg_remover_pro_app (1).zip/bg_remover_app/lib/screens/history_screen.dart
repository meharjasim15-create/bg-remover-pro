import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

/// Saare past processed photos/videos local storage se dikhata hai —
/// koi cloud account ki zaroorat nahi, sab kuch phone pe hi rehta hai.
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<FileSystemEntity> _files = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final dir = await getTemporaryDirectory();
    final allFiles = dir.listSync().where((f) =>
        f.path.endsWith('.png') || f.path.endsWith('.mp4')).toList();
    allFiles.sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    setState(() => _files = allFiles);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("History / Gallery")),
      body: _files.isEmpty
          ? const Center(child: Text("Abhi tak koi processed file nahi hai", style: TextStyle(color: Colors.grey)))
          : GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8),
              itemCount: _files.length,
              itemBuilder: (context, i) {
                final file = _files[i];
                final isVideo = file.path.endsWith('.mp4');
                return ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: isVideo
                      ? Container(color: Colors.black87, child: const Icon(Icons.play_circle, color: Colors.white, size: 36))
                      : Image.file(File(file.path), fit: BoxFit.cover),
                );
              },
            ),
    );
  }
}
