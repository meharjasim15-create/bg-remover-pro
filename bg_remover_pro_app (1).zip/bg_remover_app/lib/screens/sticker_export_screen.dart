import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ad_service.dart';
import '../services/bg_removal_service.dart';

/// Photo ko sticker jaisi transparent PNG mein convert karta hai —
/// WhatsApp stickers, social media posts, ya design projects ke liye.
class StickerExportScreen extends StatefulWidget {
  const StickerExportScreen({super.key});
  @override
  State<StickerExportScreen> createState() => _StickerExportScreenState();
}

class _StickerExportScreenState extends State<StickerExportScreen> {
  File? _selectedImage;
  File? _stickerResult;
  bool _isProcessing = false;
  final BgRemovalService _service = BgRemovalService();

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (picked != null) setState(() => _selectedImage = File(picked.path));
  }

  Future<void> _createSticker() async {
    if (_selectedImage == null) return;
    setState(() => _isProcessing = true);
    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        final result = await _service.removeBackgroundFromImage(_selectedImage!);
        setState(() {
          _stickerResult = result;
          _isProcessing = false;
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Sticker / PNG Export")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                child: _isProcessing
                    ? const Center(child: CircularProgressIndicator())
                    : (_stickerResult ?? _selectedImage) != null
                        ? ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_stickerResult ?? _selectedImage!))
                        : const Center(child: Text("Photo select karein", style: TextStyle(color: Colors.grey))),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.add_photo_alternate), label: const Text("Photo Select")),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_selectedImage != null && !_isProcessing) ? _createSticker : null,
                icon: const Icon(Icons.image),
                label: const Text("Create Sticker (Transparent PNG)"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.cyan, foregroundColor: Colors.white),
              ),
            ),
            if (_stickerResult != null) ...[
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: () {
                    // share_plus se share / gallery_saver_plus se save
                  },
                  icon: const Icon(Icons.share),
                  label: const Text("Save / Share Sticker"),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
