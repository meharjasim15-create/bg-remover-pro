import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _language = "English";
  String _exportQuality = "HD (1080p)";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Settings")),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.language),
            title: const Text("App Language"),
            subtitle: Text(_language),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showOptionPicker(
              title: "Language Select Karein",
              options: const ["English", "اردو (Urdu)", "العربية (Arabic)", "Français", "Español", "中文"],
              current: _language,
              onSelected: (v) => setState(() => _language = v),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.high_quality),
            title: const Text("Default Export Quality"),
            subtitle: Text(_exportQuality),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showOptionPicker(
              title: "Export Quality",
              options: const ["Standard (720p)", "HD (1080p)", "Ultra HD (4K)"],
              current: _exportQuality,
              onSelected: (v) => setState(() => _exportQuality = v),
            ),
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.privacy_tip_outlined),
            title: Text("Privacy Policy"),
            trailing: Icon(Icons.chevron_right),
          ),
          const ListTile(
            leading: Icon(Icons.description_outlined),
            title: Text("Terms of Use"),
            trailing: Icon(Icons.chevron_right),
          ),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text("About BG Remover Pro"),
            subtitle: Text("Version 1.0.0"),
          ),
        ],
      ),
    );
  }

  void _showOptionPicker({
    required String title,
    required List<String> options,
    required String current,
    required void Function(String) onSelected,
  }) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(padding: const EdgeInsets.all(16), child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
          ...options.map((o) => ListTile(
                title: Text(o),
                trailing: o == current ? const Icon(Icons.check, color: Colors.deepPurple) : null,
                onTap: () {
                  onSelected(o);
                  Navigator.pop(context);
                },
              )),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
