import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:before_after/before_after.dart';
import '../services/ad_service.dart';
import '../services/bg_removal_service.dart';

/// Original aur processed image ko slider se compare karne ka feature —
/// customers ko result confidently dikhane ke liye useful.
class ComparisonScreen extends StatefulWidget {
  const ComparisonScreen({super.key});
  @override
  State<ComparisonScreen> createState() => _ComparisonScreenState();
}

class _ComparisonScreenState extends State<ComparisonScreen> {
  File? _original;
  File? _processed;
  bool _isProcessing = false;
  final BgRemovalService _service = BgRemovalService();

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (picked != null) setState(() => _original = File(picked.path));
  }

  Future<void> _process() async {
    if (_original == null) return;
    setState(() => _isProcessing = true);
    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        final result = await _service.removeBackgroundFromImage(_original!);
        setState(() {
          _processed = result;
          _isProcessing = false;
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Before / After Comparison")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: _isProcessing
                  ? const Center(child: CircularProgressIndicator())
                  : (_original != null && _processed != null)
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: BeforeAfter(
                            before: Image.file(_original!, fit: BoxFit.cover),
                            after: Image.file(_processed!, fit: BoxFit.cover),
                            value: 0.5,
                          ),
                        )
                      : Container(
                          decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                          child: const Center(child: Text("Photo select karein aur process karein", style: TextStyle(color: Colors.grey))),
                        ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.add_photo_alternate), label: const Text("Photo Select")),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_original != null && !_isProcessing) ? _process : null,
                icon: const Icon(Icons.compare),
                label: const Text("Process & Compare"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange, foregroundColor: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
