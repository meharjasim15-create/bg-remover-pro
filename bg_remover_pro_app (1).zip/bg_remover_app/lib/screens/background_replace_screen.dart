import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import '../services/ad_service.dart';
import '../services/bg_removal_service.dart';

class BackgroundReplaceScreen extends StatefulWidget {
  const BackgroundReplaceScreen({super.key});
  @override
  State<BackgroundReplaceScreen> createState() => _BackgroundReplaceScreenState();
}

class _BackgroundReplaceScreenState extends State<BackgroundReplaceScreen> {
  File? _selectedImage;
  File? _resultImage;
  Color _chosenColor = Colors.white;
  bool _isProcessing = false;
  final BgRemovalService _service = BgRemovalService();

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (picked != null) setState(() => _selectedImage = File(picked.path));
  }

  void _pickColor() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Background Color Chunein"),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: _chosenColor,
            onColorChanged: (c) => setState(() => _chosenColor = c),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK"))],
      ),
    );
  }

  Future<void> _process({required bool withColor, File? customBg}) async {
    if (_selectedImage == null) return;
    setState(() => _isProcessing = true);
    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        final transparent = await _service.removeBackgroundFromImage(_selectedImage!);
        File result;
        if (withColor) {
          result = await _service.replaceBackgroundWithColor(transparent, _chosenColor);
        } else if (customBg != null) {
          result = await _service.replaceBackgroundWithImage(transparent, customBg);
        } else {
          result = await _service.blurBackground(_selectedImage!, transparent);
        }
        setState(() {
          _resultImage = result;
          _isProcessing = false;
        });
      },
    );
  }

  Future<void> _pickCustomBackground() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) await _process(withColor: false, customBg: File(picked.path));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Background Replace")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                child: _isProcessing
                    ? const Center(child: CircularProgressIndicator())
                    : _resultImage != null
                        ? ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_resultImage!))
                        : _selectedImage != null
                            ? ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_selectedImage!))
                            : const Center(child: Text("Photo select karein", style: TextStyle(color: Colors.grey))),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.add_photo_alternate), label: const Text("Photo Select")),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                ElevatedButton.icon(
                  onPressed: _selectedImage == null ? null : _pickColor,
                  icon: const Icon(Icons.color_lens),
                  label: const Text("Solid Color"),
                ),
                ElevatedButton.icon(
                  onPressed: _selectedImage == null ? null : () => _process(withColor: true),
                  icon: const Icon(Icons.check),
                  label: const Text("Apply Color"),
                ),
                ElevatedButton.icon(
                  onPressed: _selectedImage == null ? null : () => _process(withColor: false),
                  icon: const Icon(Icons.blur_on),
                  label: const Text("Blur BG"),
                ),
                ElevatedButton.icon(
                  onPressed: _selectedImage == null ? null : _pickCustomBackground,
                  icon: const Icon(Icons.image),
                  label: const Text("Custom Image BG"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
