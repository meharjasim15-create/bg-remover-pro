import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../services/ad_service.dart';

/// Premium plan screen: ads hata sakte hain subscription le kar,
/// ya thodi der ke liye rewarded ad dekh kar bhi premium features
/// temporarily unlock kar sakte hain.
class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Go Premium")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.workspace_premium, size: 80, color: Colors.amber),
            const SizedBox(height: 16),
            const Text("Premium Benefits", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            const _BenefitRow(text: "Koi ads nahi — processing se pehle koi interstitial nahi"),
            const _BenefitRow(text: "Unlimited photo & video processing"),
            const _BenefitRow(text: "4K / Ultra HD export"),
            const _BenefitRow(text: "Priority faster processing"),
            const _BenefitRow(text: "Batch processing limit hata di jati hai"),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: () {
                  // Yahan Google Play Billing / Amazon IAP / Samsung IAP
                  // integrate hoga actual subscription purchase ke liye
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.amber.shade700, foregroundColor: Colors.white),
                child: Text("Subscribe — ${AppConfig.premiumMonthlyPrice}/month"),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () {
                AdService.instance.showRewardedAd(
                  onUserEarnedReward: () {
                    // 24 ghante ke liye premium features temp unlock karein
                  },
                );
              },
              icon: const Icon(Icons.play_circle_outline),
              label: const Text("Ek video dekh kar 24hr Premium Free Unlock Karein"),
            ),
          ],
        ),
      ),
    );
  }
}

class _BenefitRow extends StatelessWidget {
  final String text;
  const _BenefitRow({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}
