import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ad_service.dart';
import '../services/video_bg_removal_service.dart';

/// ============================================================
/// VIDEO BACKGROUND REMOVER SCREEN
/// Same flow: video select -> AD dikhe -> ad ke baad processing
/// shuru ho (frame-by-frame AI background removal).
/// ============================================================
class VideoBgRemoveScreen extends StatefulWidget {
  const VideoBgRemoveScreen({super.key});

  @override
  State<VideoBgRemoveScreen> createState() => _VideoBgRemoveScreenState();
}

class _VideoBgRemoveScreenState extends State<VideoBgRemoveScreen> {
  File? _selectedVideo;
  File? _resultVideo;
  bool _isProcessing = false;
  double _progress = 0.0;
  final VideoBgRemovalService _service = VideoBgRemovalService();

  Future<void> _pickVideo() async {
    final picker = ImagePicker();
    final picked = await picker.pickVideo(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _selectedVideo = File(picked.path);
        _resultVideo = null;
      });
    }
  }

  Future<void> _onRemoveBackgroundPressed() async {
    if (_selectedVideo == null) return;
    setState(() {
      _isProcessing = true;
      _progress = 0.0;
    });

    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        try {
          final result = await _service.removeVideoBackground(
            _selectedVideo!,
            onProgress: (p) => setState(() => _progress = p),
          );
          setState(() {
            _resultVideo = result;
            _isProcessing = false;
          });
        } catch (e) {
          setState(() => _isProcessing = false);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Video processing failed: $e")),
            );
          }
        }
      },
    );
  }

  @override
  void dispose() {
    _service.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Video Background Remover")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: _isProcessing
                      ? Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircularProgressIndicator(value: _progress),
                            const SizedBox(height: 12),
                            Text("${(_progress * 100).toStringAsFixed(0)}% — frame-by-frame AI processing"),
                          ],
                        )
                      : _resultVideo != null
                          ? Column(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Icon(Icons.check_circle, color: Colors.green, size: 60),
                                SizedBox(height: 8),
                                Text("Video ready! Background removed."),
                              ],
                            )
                          : _selectedVideo != null
                              ? const Icon(Icons.movie, size: 80, color: Colors.deepPurple)
                              : const Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.video_call_outlined, size: 80, color: Colors.grey),
                                    SizedBox(height: 12),
                                    Text("Koi video select karein", style: TextStyle(color: Colors.grey)),
                                  ],
                                ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: _pickVideo,
              icon: const Icon(Icons.video_library),
              label: const Text("Select Video"),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_selectedVideo != null && !_isProcessing) ? _onRemoveBackgroundPressed : null,
                icon: const Icon(Icons.auto_fix_high),
                label: Text(_isProcessing ? "Processing..." : "Remove Background"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
