import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ad_service.dart';
import '../services/bg_removal_service.dart';

/// Multiple photos ek saath process karne ke liye.
/// Ad sirf EK BAAR dikhti hai pure batch ke shuru mein (user-friendly),
/// fir saari photos background-removed ho kar process hoti hain.
class BatchProcessScreen extends StatefulWidget {
  const BatchProcessScreen({super.key});
  @override
  State<BatchProcessScreen> createState() => _BatchProcessScreenState();
}

class _BatchProcessScreenState extends State<BatchProcessScreen> {
  List<File> _selectedImages = [];
  List<File> _results = [];
  bool _isProcessing = false;
  int _doneCount = 0;
  final BgRemovalService _service = BgRemovalService();

  Future<void> _pickImages() async {
    final picked = await ImagePicker().pickMultiImage(imageQuality: 90);
    if (picked.isNotEmpty) {
      setState(() {
        _selectedImages = picked.map((x) => File(x.path)).toList();
        _results = [];
      });
    }
  }

  Future<void> _processAll() async {
    if (_selectedImages.isEmpty) return;
    setState(() {
      _isProcessing = true;
      _doneCount = 0;
      _results = [];
    });

    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        final results = <File>[];
        for (final img in _selectedImages) {
          final r = await _service.removeBackgroundFromImage(img);
          results.add(r);
          setState(() => _doneCount++);
        }
        setState(() {
          _results = results;
          _isProcessing = false;
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Batch Processing")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            OutlinedButton.icon(
              onPressed: _pickImages,
              icon: const Icon(Icons.photo_library),
              label: Text(_selectedImages.isEmpty ? "Multiple Photos Select Karein" : "${_selectedImages.length} photos selected"),
            ),
            const SizedBox(height: 12),
            if (_isProcessing)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    LinearProgressIndicator(value: _selectedImages.isEmpty ? 0 : _doneCount / _selectedImages.length),
                    const SizedBox(height: 8),
                    Text("$_doneCount / ${_selectedImages.length} processed"),
                  ],
                ),
              ),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8),
                itemCount: _results.isNotEmpty ? _results.length : _selectedImages.length,
                itemBuilder: (context, i) {
                  final file = _results.isNotEmpty ? _results[i] : _selectedImages[i];
                  return ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(file, fit: BoxFit.cover));
                },
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_selectedImages.isNotEmpty && !_isProcessing) ? _processAll : null,
                icon: const Icon(Icons.auto_fix_high),
                label: const Text("Remove Background (All)"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
