import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/watermark_service.dart';

/// ============================================================
/// MY WATERMARK / LOGO STUDIO
/// Ye feature user ko apna KHUD ka logo ya text watermark add
/// karne deta hai (jaise "JN9 Sports" ya "Tan & Stitch" branding).
/// App khud kabhi koi watermark force nahi karti — output hamesha
/// clean hota hai jab tak user khud is screen se add na kare.
/// ============================================================
class WatermarkStudioScreen extends StatefulWidget {
  const WatermarkStudioScreen({super.key});
  @override
  State<WatermarkStudioScreen> createState() => _WatermarkStudioScreenState();
}

class _WatermarkStudioScreenState extends State<WatermarkStudioScreen> {
  File? _baseImage;
  File? _userLogo;
  File? _resultImage;
  String _position = "bottom-right";
  final WatermarkService _service = WatermarkService();
  final TextEditingController _textController = TextEditingController();

  Future<void> _pickBaseImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (picked != null) setState(() => _baseImage = File(picked.path));
  }

  Future<void> _pickUserLogo() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (picked != null) setState(() => _userLogo = File(picked.path));
  }

  Future<void> _applyLogo() async {
    if (_baseImage == null || _userLogo == null) return;
    final result = await _service.addUserLogoWatermark(
      processedImage: _baseImage!,
      userLogoFile: _userLogo!,
      position: _position,
    );
    setState(() => _resultImage = result);
  }

  Future<void> _applyText() async {
    if (_baseImage == null || _textController.text.trim().isEmpty) return;
    final result = await _service.addUserTextWatermark(
      processedImage: _baseImage!,
      text: _textController.text.trim(),
      position: _position,
    );
    setState(() => _resultImage = result);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("My Watermark / Logo Studio")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.amber.shade50, borderRadius: BorderRadius.circular(10)),
              child: const Text(
                "Ye sirf APKE apne logo/text se watermark add karta hai. App khud koi watermark nahi lagati.",
                style: TextStyle(fontSize: 12.5),
              ),
            ),
            const SizedBox(height: 16),
            AspectRatio(
              aspectRatio: 1,
              child: Container(
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                child: (_resultImage ?? _baseImage) != null
                    ? ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_resultImage ?? _baseImage!))
                    : const Center(child: Text("Photo select karein", style: TextStyle(color: Colors.grey))),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: _pickBaseImage, icon: const Icon(Icons.image), label: const Text("1. Apni Photo Select Karein")),
            const SizedBox(height: 10),
            OutlinedButton.icon(onPressed: _pickUserLogo, icon: const Icon(Icons.badge), label: const Text("2. Apna Logo Upload Karein")),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _position,
              decoration: const InputDecoration(labelText: "Logo Position", border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: "bottom-right", child: Text("Bottom Right")),
                DropdownMenuItem(value: "bottom-left", child: Text("Bottom Left")),
                DropdownMenuItem(value: "top-right", child: Text("Top Right")),
                DropdownMenuItem(value: "top-left", child: Text("Top Left")),
                DropdownMenuItem(value: "center", child: Text("Center")),
              ],
              onChanged: (v) => setState(() => _position = v!),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: (_baseImage != null && _userLogo != null) ? _applyLogo : null,
              icon: const Icon(Icons.branding_watermark),
              label: const Text("Apply My Logo"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.brown, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(48)),
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            TextField(
              controller: _textController,
              decoration: const InputDecoration(labelText: "Ya apna brand naam likhein (e.g. JN9 Sports)", border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: _baseImage != null ? _applyText : null,
              icon: const Icon(Icons.text_fields),
              label: const Text("Apply Text Watermark"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.brown.shade300, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(48)),
            ),
          ],
        ),
      ),
    );
  }
}
