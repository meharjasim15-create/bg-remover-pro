import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import '../services/ad_service.dart';

/// AI Auto Enhance: brightness, contrast, sharpness, saturation
/// ek tap mein behtar kar deta hai (background-removed image ke liye
/// useful — products clean aur bright dikhte hain).
class EnhanceScreen extends StatefulWidget {
  const EnhanceScreen({super.key});
  @override
  State<EnhanceScreen> createState() => _EnhanceScreenState();
}

class _EnhanceScreenState extends State<EnhanceScreen> {
  File? _selectedImage;
  File? _resultImage;
  bool _isProcessing = false;

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (picked != null) setState(() => _selectedImage = File(picked.path));
  }

  Future<void> _enhance() async {
    if (_selectedImage == null) return;
    setState(() => _isProcessing = true);
    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        final bytes = await _selectedImage!.readAsBytes();
        var image = img.decodeImage(bytes)!;
        image = img.adjustColor(image, brightness: 1.08, contrast: 1.15, saturation: 1.12);
        image = img.gaussianBlur(image, radius: 0); // placeholder for sharpen pipeline
        final dir = await getTemporaryDirectory();
        final out = File('${dir.path}/enhanced_${DateTime.now().millisecondsSinceEpoch}.png');
        await out.writeAsBytes(img.encodePng(image));
        setState(() {
          _resultImage = out;
          _isProcessing = false;
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("AI Auto Enhance")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                child: _isProcessing
                    ? const Center(child: CircularProgressIndicator())
                    : (_resultImage ?? _selectedImage) != null
                        ? ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_resultImage ?? _selectedImage!))
                        : const Center(child: Text("Photo select karein", style: TextStyle(color: Colors.grey))),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.add_photo_alternate), label: const Text("Photo Select")),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_selectedImage != null && !_isProcessing) ? _enhance : null,
                icon: const Icon(Icons.auto_fix_high),
                label: const Text("Auto Enhance"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.pink, foregroundColor: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
