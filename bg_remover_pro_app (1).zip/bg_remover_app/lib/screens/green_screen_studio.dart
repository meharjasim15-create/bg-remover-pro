import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ad_service.dart';
import '../services/video_bg_removal_service.dart';

/// Video ko pure green/blue screen background ke saath export karta hai —
/// professional video editors (CapCut, Premiere, etc.) mein use karne ke liye.
class GreenScreenStudio extends StatefulWidget {
  const GreenScreenStudio({super.key});
  @override
  State<GreenScreenStudio> createState() => _GreenScreenStudioState();
}

class _GreenScreenStudioState extends State<GreenScreenStudio> {
  File? _selectedVideo;
  File? _resultVideo;
  bool _isProcessing = false;
  double _progress = 0;
  final VideoBgRemovalService _service = VideoBgRemovalService();

  Future<void> _pickVideo() async {
    final picked = await ImagePicker().pickVideo(source: ImageSource.gallery);
    if (picked != null) setState(() => _selectedVideo = File(picked.path));
  }

  Future<void> _process() async {
    if (_selectedVideo == null) return;
    setState(() {
      _isProcessing = true;
      _progress = 0;
    });
    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        final result = await _service.removeVideoBackground(
          _selectedVideo!,
          onProgress: (p) => setState(() => _progress = p),
          newBackgroundColorHex: "#00FF00",
        );
        setState(() {
          _resultVideo = result;
          _isProcessing = false;
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Green Screen Studio")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(12)),
              child: const Text(
                "Video editing apps (CapCut, Premiere, etc.) mein use karne ke liye pure green-screen background ke saath video export hoga.",
                style: TextStyle(fontSize: 13),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(16)),
                child: Center(
                  child: _isProcessing
                      ? Column(mainAxisSize: MainAxisSize.min, children: [
                          CircularProgressIndicator(value: _progress),
                          const SizedBox(height: 8),
                          Text("${(_progress * 100).toStringAsFixed(0)}%"),
                        ])
                      : _resultVideo != null
                          ? const Icon(Icons.check_circle, color: Colors.green, size: 60)
                          : const Icon(Icons.movie_creation_outlined, size: 70, color: Colors.grey),
                ),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: _pickVideo, icon: const Icon(Icons.video_library), label: const Text("Video Select")),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_selectedVideo != null && !_isProcessing) ? _process : null,
                icon: const Icon(Icons.theaters),
                label: const Text("Generate Green Screen Video"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
