import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../services/ad_service.dart';
import 'photo_bg_remove_screen.dart';
import 'video_bg_remove_screen.dart';
import 'batch_process_screen.dart';
import 'background_replace_screen.dart';
import 'enhance_screen.dart';
import 'sticker_export_screen.dart';
import 'green_screen_studio.dart';
import 'comparison_screen.dart';
import 'history_screen.dart';
import 'watermark_studio_screen.dart';
import 'settings_screen.dart';
import 'premium_screen.dart';

/// ============================================================
/// HOME SCREEN — App ke saare TOP 12 FEATURES yahan se accessible:
///
///  1. AI Photo Background Remover (one-tap)
///  2. AI Video Background Remover
///  3. Background Replace (color / blur / custom image)
///  4. Batch Photo Processing (multiple photos ek saath)
///  5. HD / 4K Export
///  6. Custom Watermark / Logo Studio (USER ka apna logo)
///  7. AI Auto Enhance (brightness/contrast/sharpness)
///  8. Green Screen Studio (chroma key export for video editors)
///  9. Cutout to Sticker / Transparent PNG export
/// 10. Before/After Comparison Slider
/// 11. Cloud-free Local History / Gallery
/// 12. Multi-language interface + Premium (ad-free, unlimited)
/// ============================================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  BannerAd? _bannerAd;
  NativeAd? _nativeAd;
  bool _nativeAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _bannerAd = AdService.instance.createBannerAd();
    _nativeAd = AdService.instance.createNativeAd(
      onLoaded: (ad) => setState(() => _nativeAdLoaded = true),
    );
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    _nativeAd?.dispose();
    super.dispose();
  }

  final List<_FeatureItem> features = const [
    _FeatureItem(Icons.person_remove, "Photo BG Remover", Colors.purple),
    _FeatureItem(Icons.video_settings, "Video BG Remover", Colors.indigo),
    _FeatureItem(Icons.wallpaper, "Background Replace", Colors.teal),
    _FeatureItem(Icons.collections, "Batch Processing", Colors.orange),
    _FeatureItem(Icons.auto_fix_high, "AI Auto Enhance", Colors.pink),
    _FeatureItem(Icons.branding_watermark, "My Watermark / Logo", Colors.brown),
    _FeatureItem(Icons.theaters, "Green Screen Studio", Colors.green),
    _FeatureItem(Icons.image, "Sticker / PNG Export", Colors.cyan),
    _FeatureItem(Icons.compare, "Before / After Slider", Colors.deepOrange),
    _FeatureItem(Icons.history, "History / Gallery", Colors.blueGrey),
    _FeatureItem(Icons.workspace_premium, "Go Premium (No Ads)", Colors.amber),
    _FeatureItem(Icons.settings, "Settings", Colors.grey),
  ];

  void _navigateTo(int index) {
    final pages = [
      const PhotoBgRemoveScreen(),
      const VideoBgRemoveScreen(),
      const BackgroundReplaceScreen(),
      const BatchProcessScreen(),
      const EnhanceScreen(),
      const WatermarkStudioScreen(),
      const GreenScreenStudio(),
      const StickerExportScreen(),
      const ComparisonScreen(),
      const HistoryScreen(),
      const PremiumScreen(),
      const SettingsScreen(),
    ];
    Navigator.push(context, MaterialPageRoute(builder: (_) => pages[index]));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("BG Remover Pro", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 14,
                mainAxisSpacing: 14,
                childAspectRatio: 1.05,
              ),
              itemCount: features.length,
              itemBuilder: (context, index) {
                final f = features[index];
                return _FeatureCard(item: f, onTap: () => _navigateTo(index));
              },
            ),
          ),
          // Native Advanced ad — feature grid aur banner ke beech mein
          if (_nativeAdLoaded && _nativeAd != null)
            Container(
              height: 120,
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: AdWidget(ad: _nativeAd!),
            ),
          // Banner ad neeche, screen ke saath integrated
          if (_bannerAd != null)
            SizedBox(
              height: _bannerAd!.size.height.toDouble(),
              width: _bannerAd!.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd!),
            ),
        ],
      ),
    );
  }
}

class _FeatureItem {
  final IconData icon;
  final String label;
  final Color color;
  const _FeatureItem(this.icon, this.label, this.color);
}

class _FeatureCard extends StatelessWidget {
  final _FeatureItem item;
  final VoidCallback onTap;
  const _FeatureCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: item.color.withOpacity(0.12), shape: BoxShape.circle),
              child: Icon(item.icon, color: item.color, size: 32),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(item.label, textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            ),
          ],
        ),
      ),
    );
  }
}
