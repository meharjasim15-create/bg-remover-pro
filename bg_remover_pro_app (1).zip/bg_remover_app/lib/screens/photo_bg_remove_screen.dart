import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ad_service.dart';
import '../services/bg_removal_service.dart';

/// ============================================================
/// PHOTO BACKGROUND REMOVER SCREEN
/// Flow (jaisa aapne maanga):
///   1. User photo select kare
///   2. "Remove Background" dabaye
///   3. Interstitial AD dikhe
///   4. Ad band hone ke baad hi AI processing chale
///   5. Result (transparent PNG) dikhe + save/share options
/// ============================================================
class PhotoBgRemoveScreen extends StatefulWidget {
  const PhotoBgRemoveScreen({super.key});

  @override
  State<PhotoBgRemoveScreen> createState() => _PhotoBgRemoveScreenState();
}

class _PhotoBgRemoveScreenState extends State<PhotoBgRemoveScreen> {
  File? _selectedImage;
  File? _resultImage;
  bool _isProcessing = false;
  final BgRemovalService _service = BgRemovalService();

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: source, imageQuality: 95);
    if (picked != null) {
      setState(() {
        _selectedImage = File(picked.path);
        _resultImage = null;
      });
    }
  }

  /// Yahan ad pehle dikhti hai, uske baad hi processing start hoti hai
  Future<void> _onRemoveBackgroundPressed() async {
    if (_selectedImage == null) return;

    setState(() => _isProcessing = true);

    await AdService.instance.showInterstitialBeforeProcessing(
      onAdComplete: () async {
        try {
          final result = await _service.removeBackgroundFromImage(_selectedImage!);
          setState(() {
            _resultImage = result;
            _isProcessing = false;
          });
        } catch (e) {
          setState(() => _isProcessing = false);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Processing failed: $e")),
            );
          }
        }
      },
    );
  }

  @override
  void dispose() {
    _service.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Photo Background Remover")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: _isProcessing
                    ? const Center(child: CircularProgressIndicator())
                    : _resultImage != null
                        ? _CheckeredBackground(child: Image.file(_resultImage!))
                        : _selectedImage != null
                            ? ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(_selectedImage!))
                            : const Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.image_outlined, size: 80, color: Colors.grey),
                                    SizedBox(height: 12),
                                    Text("Koi photo select karein", style: TextStyle(color: Colors.grey)),
                                  ],
                                ),
                              ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickImage(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library),
                    label: const Text("Gallery"),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickImage(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text("Camera"),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_selectedImage != null && !_isProcessing) ? _onRemoveBackgroundPressed : null,
                icon: const Icon(Icons.auto_fix_high),
                label: Text(_isProcessing ? "Processing..." : "Remove Background"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
              ),
            ),
            if (_resultImage != null) ...[
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton.icon(
                  onPressed: () {
                    // gallery_saver_plus se save karein, ya share_plus se share karein
                  },
                  icon: const Icon(Icons.download),
                  label: const Text("Save HD Result (No Watermark)"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Transparent PNG ko achi tarah dikhane ke liye checkered pattern background
class _CheckeredBackground extends StatelessWidget {
  final Widget child;
  const _CheckeredBackground({required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        CustomPaint(painter: _CheckerPainter()),
        Center(child: child),
      ],
    );
  }
}

class _CheckerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const tile = 16.0;
    final paint1 = Paint()..color = Colors.grey.shade200;
    final paint2 = Paint()..color = Colors.grey.shade300;
    for (double y = 0; y < size.height; y += tile) {
      for (double x = 0; x < size.width; x += tile) {
        final isEven = ((x / tile).floor() + (y / tile).floor()) % 2 == 0;
        canvas.drawRect(Rect.fromLTWH(x, y, tile, tile), isEven ? paint1 : paint2);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
